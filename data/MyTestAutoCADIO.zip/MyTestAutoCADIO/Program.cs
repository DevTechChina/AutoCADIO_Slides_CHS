﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 

namespace MyTestAutoCADIO
{
    class Program
    {    
        [STAThread]
        static void Main(string[] args)
        {
            //创建与AutoCAD IO 通讯的代理人口
            Uri uri = new Uri("https://developer.api.autodesk.com/autocad.io/v1/");
            //服务的容器
            var container = new AcadIO.Container(uri);
            //指定使用Json进行通讯
            container.Format.UseJson();
            //开发者的 API  key
            var clientId = "你的key";
            //开发者的 API  secret
            var clientSecret = "你的secret";
            //AutoCAD IO 返回的口令
            string token = null;
                       
            using (var client = new HttpClient())
            {
                //配置HTTP请求。其中有两个参数是开发者的API key和 secret
                var values = new List<KeyValuePair<string, string>>();
                values.Add(new KeyValuePair<string, string>("client_id", clientId));
                values.Add(new KeyValuePair<string, string>("client_secret", clientSecret));
                values.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));

                var requestContent = new FormUrlEncodedContent(values);

                //向AutoCADI/O发出认证请求
                //服务端点地址为: https://developer.api.autodesk.com/authentication/v1/authenticate
                var response = client.PostAsync("https://developer.api.autodesk.com/authentication/v1/authenticate", 
                                requestContent).Result;

                //得到响应，查看返回结果
                var responseContent = response.Content.ReadAsStringAsync().Result;
                //解析返回的Json字串
                var resValues = JsonConvert.DeserializeObject<Dictionary<string, string>>(responseContent);
                //提取出口令（token）
                token = resValues["token_type"] + " " + resValues["access_token"];
            }

            //将口令设置到随后所有AutoCAD I/O相关请求的HTTP头
            if (!string.IsNullOrEmpty(token))
               container.SendingRequest2 += (sender, e) => e.RequestMessage.SetHeader("Authorization", token);

            
            //接下来可以进行AutoCAD I/O的其它操作
            //.....

            //遍历Activity
            // GetActivities(container);

            //遍历WorkItem
            //GetWorkItems(container);

            //创建Activity
            //AcadIO.Activity act =  CreateActivity(container);
            //执行批处理任务 （WorkItem）
            //CreateWorkItem(container, act);  

        }

        static void GetWorkItems(AcadIO.Container container)
        {            
            foreach (var wi in container.WorkItems)
            {
                //打印UserId和Id               
                Console.WriteLine("{0} {1}", wi.UserId, wi.Id);
                Console.WriteLine("{0} ", wi.ActivityId);
                Console.WriteLine("{0} ", wi.Status);
                //打印输入参数
                Console.WriteLine(" workitem StatusDetails:{0}", wi.StatusDetails);
            }
        }

        static void GetActivities(AcadIO.Container container)
        {
            foreach (var act in container.Activities)
            {
                //打印UserId和Id
                Console.WriteLine("{0} {1}", act.UserId, act.Id);

                //打印输入参数
                Console.WriteLine(" Input Parameters:");
                foreach (var inputP in act.Parameters.InputParameters)
                {
                    Console.WriteLine("     {0}", inputP.Name);
                }
                //打印输出参数
                Console.WriteLine(" Output Parameters:");
                foreach (var outputP in act.Parameters.OutputParameters)
                {
                    Console.WriteLine("     {0}", outputP.Name);
                } 
            }

        } 

        static AcadIO.Activity CreateActivity(AcadIO.Container container)
        {
            //若已经存在该Activity，删掉
            var act = container.Activities.Where(a => a.Id == "MyCreateALine").FirstOrDefault();
            if (act != null)
            {
                container.DeleteObject(act);
                container.SaveChanges();                 
            }

            //新建Activity
            act = new AcadIO.Activity()
            {
                UserId = "",
                Id = "MyCreateALine",//Activity名
                Version = 1,
                Instruction = new AcadIO.Instruction()
                {
                    //执行的脚本
                    Script = "_tilemode 1 _line 0,0 1,1  _save /result.dwg\n"
                },
                Parameters = new AcadIO.Parameters()
                {
                    //输入的参数
                    InputParameters = { new AcadIO.Parameter() { Name = "HostDwg", LocalFileName = "$(HostDwg)" } },
                    //输出的参数
                    OutputParameters = { new AcadIO.Parameter() { Name = "Result", LocalFileName = "result.dwg" } }
                },
                //AutoCAD版本
                RequiredEngineVersion = "20.0"
            };
            //添加activity
            container.AddToActivities(act);
            //执行保存
            container.SaveChanges();
            return act;
        }

        static void CreateWorkItem(AcadIO.Container container,AcadIO.Activity _act )
        {
            //新建WorkItem
            var wi = new AcadIO.WorkItem()
            {
                UserId = "", //必须为空，AutoCAD I/O会自动分配Guid
                Id = "", //必须为空，AutoCAD I/O会自动分配Guid
                Arguments = new AcadIO.Arguments(),
                Version = 1,
                //用哪个Activity
                ActivityId = new AcadIO.EntityId() { UserId = _act.UserId, Id = _act.Id }
            };
            //设置输入参数
            wi.Arguments.InputArguments.Add(new AcadIO.Argument()
            {
                //对应Activity哪个参数 
                Name = "HostDwg",
                //来源。               
                Resource = "http://testio.oss-cn-beijing.aliyuncs.com/aaa.dwg",              
                //非A360数据源
                StorageProvider = "Generic" 
            });
            //设置输出参数
            wi.Arguments.OutputArguments.Add(new AcadIO.Argument()
            {
                //对应Activity哪个参数 
                Name = "Result",
                //非A360数据源
                StorageProvider = "Generic",
                //HTTP动作 - 将结果放到对应的云存储
                HttpVerb = "POST",
                //如果设置为null，则缺省放到AutoCAD I/O存储空间里
                Resource = null
            });

            //添加此WorkItem, 也就是开始启动任务
            container.AddToWorkItems(wi);
            container.SaveChanges();

            //看看AutoCAD I/O为WorkItem分配了什么Guid
            Console.WriteLine("UserId = {0}, Id= {1}", wi.UserId, wi.Id); 
            
            container.MergeOption = System.Data.Services.Client.MergeOption.OverwriteChanges;

            //等待，看看该任务WorkItem是否执行完毕
            do
            {
                System.Threading.Thread.Sleep(10000);
                wi = container.WorkItems.Where(p => p.UserId == wi.UserId && p.Id == wi.Id).SingleOrDefault();
            }
            while (wi.Status == "Pending" || wi.Status == "InProgress");

            if (wi.Status == "Succeeded")
            {
                //若成功结束，看看转换后的文件url
                Console.WriteLine("The result is downloadable at {0}",
                    wi.Arguments.OutputArguments.First().Resource);
                String localFilePath = String.Empty;
                if (!Download(wi.Arguments.OutputArguments.First().Resource.ToString(), ref localFilePath))
                {
                    Console.WriteLine("failed to get the result file!");
                }
            }  
        }

        public static bool Download(String url, ref String localFilePath)
        {
            try
            {
                if (String.IsNullOrEmpty(url))
                    return false;

                // 保存文件到本地 My Document 文件夹
                if (url.StartsWith("http://") || url.StartsWith("https://"))
                {
                    String filename = Path.GetFileName(new Uri(url).AbsolutePath);
                    localFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), filename);
                    using (System.Net.WebClient wc = new System.Net.WebClient())
                    {
                        wc.DownloadFile(url, localFilePath);
                    }

                    if (!String.IsNullOrEmpty(localFilePath))
                    {
                        return true;
                    }
                }
            }
            catch (System.UriFormatException)
            {
                Console.WriteLine(url + "could not be loaded.");
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            localFilePath = String.Empty;
            return false;
        }
 

    }
}
