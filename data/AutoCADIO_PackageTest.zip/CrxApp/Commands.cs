﻿using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Autodesk.AutoCAD.DatabaseServices;
 

[assembly: CommandClass(typeof(CrxApp.Commands))]
[assembly: ExtensionApplication(null)]

namespace CrxApp
{
    
    public class Commands
    {
        [CommandMethod("MyTestCommands","MyDrawText",CommandFlags.Modal)]
        public void MyDrawText()
        {
            Database db = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead, false);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite, false);

                DBText dbtxt = new DBText();
                dbtxt.TextString = "Shanghai AutoCAD IO training!";

                btr.AppendEntity(dbtxt);
                tr.AddNewlyCreatedDBObject(dbtxt, true);
                tr.Commit();
            }
        }
    }
}
